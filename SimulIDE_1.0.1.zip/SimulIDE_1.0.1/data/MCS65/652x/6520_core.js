
var pra = 0;

function reset()
{ 
    print("resetting 6520 "); 
}

function runClock( clkState )
{
    print("6520 runClock " + clkState ); 
    
}
